#import required library
import bs4
from bs4 import BeautifulSoup
from selenium import webdriver
import pandas as ps
import csv


#Specify the browser.exe path

path='' #past path for the driver
#set browser driver to variable 
driver = webdriver.Chrome(path)
#set url fo the site to scrap
url = "https://www.amazon.com/dp/"

#Make item list to pars as link to scrap the data 

column_names = ["ASIN"]
asin_path='' #past path for thr asin file
df = ps.read_csv(asin_path, names=column_names)
item_list =df.ASIN.to_list()


def scrap():
#defining file with .csv
    file_N = 'placement_2021.csv'
    f=open(file_N,'w',newline='')
    placement = csv.writer(f)
    row_1st=['Upc_Code','NAME', 'Price','Category','Sub-category','Images','Rateing','T_rating', 'Brand', 'Manufacturer', 'Weight','Dimention' ]
    placement.writerow(row_1st)
    
    length=len(item_list)
    #Iterate item list
    for i in range(1,length-19990):
        #making URL for ASIN code 
        driver.get(url + item_list[i])
        #creating BeautifulSoup for HTML
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        item=soup.find('div',class_ = 'centerColAlign centerColAlign-bbcxoverride')
        #process valid and available product
        if item:
            Item_info=item.div.h1.text
            Item_info=Item_info.replace('\n','')
            rate=item.find_all('i')
            if rate:
                rate=rate[0].text[:3]
                Rate=rate
            else:
                Rate='none'
            #refining catagory sub-catagory
            ab=soup.find_all('a',class_ ='a-link-normal a-color-tertiary')
            ab[0:2]
            res=[]
            for i in ab:
                res.append(i.text.replace(' ',''))
            res=[i[1:-2] for i in res] 
            if res:
                Category=res[0]
                Sub_category=res[1]
            else:
                Category='none'
                Sub_category='none'
            #dimention,USA,manufature details
            mf=soup.find('ul',class_ = 'a-unordered-list a-nostyle a-vertical a-spacing-none detail-bullet-list')
            if mf:
                man=mf.text
                fm=man[33:].split('\n')
                fm =[i for i in fm if i]
                if len(fm) > 10:
                    if fm[4] and fm[7] and fm[-4]:
                        dimen,Upc_Code,Manufacturer=(fm[4],fm[7],fm[-4])
                else:
                    dimen,Upc_Code,Manufacturer=('none','none','none')
                if ';' in dimen:
                    Dimention,Weight=dimen.split(';')
                else:
                    Dimention,Weight='4.12 x 2.94 x 3.94 inches', '8.12 Ounces'
            else:
                Dimention,Weight,Upc_Code,Manufacturer=('none','none','none','none')
            Brand=item.find('a', class_='a-link-normal')
            if Brand:
                Brand=Brand.text[6:]
            T_rating = item.find('span', class_='a-size-base')
            if T_rating:
                T_rating =T_rating.text
                if 'ratings' in T_rating:
                    T_rating,ra=T_rating.split()
            Price=item.find('span', class_='a-size-medium a-color-price priceBlockBuyingPriceString')
            if Price:
                Price=Price.text
            else:
                Price='none'
            images=item.find_all('img')
            if images:
                Images_link=[i['src'] for i in images]
            else:
                Images_link='none' ;
            cols=[Upc_Code,Item_info, Price,Category,Sub_category,Images_link,Rate,
                  T_rating, Brand, Manufacturer, Weight,Dimention]
            placement.writerow(cols)
scrap()