#import required library
import bs4
from bs4 import BeautifulSoup
from selenium import webdriver
import pandas as ps
import csv

#Specify the browser.exe path

path=input("Enter the Chromedriver path...>>")
#set browser driver to variable 
driver = webdriver.Chrome(path)
#set url fo the site to scrap
url = "https://www.amazon.com/dp/"

#Make item list to pars as link to scrap the data 

column_names = ["ASIN"]
asin_path=input('Enter path for asin file...>>')
df = ps.read_csv(asin_path, names=column_names)
item_list =df.ASIN.to_list()




def scrap():
    #defining file with .csv
    file_N = 'placement_2021.csv'
    f=open(file_N,'w',newline='')
    placement = csv.writer(f)
    row_1st=['Item_info', 'Rate', 'Brand', 'T_rating', 'Price', 'Images']
    placement.writerow(row_1st)
    
    #Iterate item list
    for i in range(1,len(item_list)-19900):
        #making URL for ASIN code 
        driver.get(url + item_list[i])
        #creating BeautifulSoup for HTML
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        item=soup.find('div',class_ = 'centerColAlign centerColAlign-bbcxoverride')
        #process valid and available product
        if item:
            Item_info=item.div.h1.text
            Item_info=Item_info.replace('\n','')
            rate=item.find_all('i')
            if rate:
                rate=rate[0].text[:3]
                Rate=float(rate)
            else:
                Rate='none'
            Brand=item.find('a', class_='a-link-normal').text[6:]
            T_rating = item.find('span', class_='a-size-base').text
            if 'ratings' in T_rating:
                T_rating,ra=T_rating.split()
            Price=item.find('span', class_='a-size-medium a-color-price priceBlockBuyingPriceString')
            if Price:
                Price=Price.text
            else:
                Price='none'
            images=item.find_all('img')
            if images:
                Images_link=[i['src'] for i in images]
            else:
                Images_link='none' ;
            cols=[Item_info, Rate, Brand, T_rating, Price, Images_link]
            placement.writerow(cols)
            file_N.close()
scrap()